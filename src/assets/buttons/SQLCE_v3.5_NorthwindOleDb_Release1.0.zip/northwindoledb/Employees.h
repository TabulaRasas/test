/***********************************************************************
Copyright (c) 1999 - 2002, Microsoft Corporation
All Rights Reserved.
***********************************************************************/

// Employees.h: interface for the Employees class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EMPLOYEES_H__D7DFE6F5_14A2_4B9B_B450_9D02486C0252__INCLUDED_)
#define AFX_EMPLOYEES_H__D7DFE6F5_14A2_4B9B_B450_9D02486C0252__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"
#include "resource.h"

class Employees
{
public:
	Employees(BOOL *pSuccess = NULL);
	virtual ~Employees();

	HWND	Create(HWND hWndParent, HINSTANCE hInstance);
	HRESULT LoadEmployeeInfo(DWORD dwEmployeeID);
	HRESULT SaveEmployeeInfo(DWORD dwEmployeeID);
	void	ShowEmployeePhoto();

private:
	HRESULT InitDatabase();
	HRESULT OpenDatabase();
	HRESULT CreateDatabase();
	HRESULT ExecuteSQL(ICommandText *pICmdText, WCHAR * pwszQuery);
	HRESULT PopulateEmployeeNameList();
	HRESULT LoadEmployeePhoto(ILockBytes* pILockBytes);
	HRESULT InsertEmployeeInfo();
	void	ClearEmployeeInfo();
	HRESULT	SaveEmployeePhoto(ISequentialStream* pISequentialStream, DWORD dwPhotoID);
	BOOL	GetColumnOrdinal(DBCOLUMNINFO* pDBColumnInfo, DWORD dwNumCols, WCHAR* pwszColName, DWORD* pOrdinal);

private:
	IDBCreateSession *m_pIDBCreateSession;  // The IDBCreateSession interface
	HWND			 m_hWndEmployees;		// The employees dialog for the controls
	HINSTANCE		 m_hInstance;
	HBITMAP			 m_hBitmap;
};

#endif // !defined(AFX_EMPLOYEES_H__D7DFE6F5_14A2_4B9B_B450_9D02486C0252__INCLUDED_)
