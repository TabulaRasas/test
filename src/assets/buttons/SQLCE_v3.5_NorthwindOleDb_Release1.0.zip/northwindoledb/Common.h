/***********************************************************************
Copyright (c) 1999 - 2002, Microsoft Corporation
All Rights Reserved.
***********************************************************************/

#ifndef NORTHWIND_OLEDB_SAMPLE_COMMON_INCLUDED
#define NORTHWIND_OLEDB_SAMPLE_COMMON_INCLUDED	

// Exclude rarely-used stuff from Windows headers
//
#define WIN32_LEAN_AND_MEAN		

// constants
//
const int MENU_HEIGHT				= 26;
const int MAX_LOADSTRING			= 100;		// Maximun lenght for resource strings
const int MAX_DATABASENAME_LENGHT	= 256;		// Maximun lenght for a database name
const int MAX_TABLENAME_LENGHT		= 256;		// Maximun lenght for a table name
const int MAX_INDEXNAME_LENGHT		= 256;		// Maximun lenght for a index name
const int MAX_QUERY_LENGTH			= 256;		// Maximun lenght for a query
const int COLUMN_ALIGNVAL           = 8;		// Column alignment value
 
// Constants for displaying employee photo
//
const int PHOTO_X					= 10;
const int PHOTO_Y					= 130;
const int PHOTO_WIDTH				= 104;
const int PHOTO_HEIGHT				= 120;

// Return a properly aligned size
//
inline DWORD ROUND_UP(DWORD dwSize, DWORD dwAmount) { return ((dwSize + (dwAmount-1)) & ~(dwAmount-1));}

#endif // NORTHWIND_OLEDB_SAMPLE_COMMON_INCLUDED