//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NorthwindOleDb.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_NORTHWINDOLEDB              3
#define IDI_NORTHWINDOLEDB              101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDD_DIALOG_EMPLOYEES            104
#define IDR_PHOTO_SUYAMA                104
#define IDR_PHOTO_BUCHANAN              105
#define IDR_PHOTO_CALLAHAN              106
#define IDR_PHOTO_DEVOLIO               107
#define IDR_PHOTO_DODSWORTH             108
#define IDR_PHOTO_FULLER                109
#define IDR_PHOTO_KING                  110
#define IDR_PHOTO_LEVERLING             111
#define IDR_PHOTO_PEACOCK               112
#define IDR_PHOTO_DAVOLIO               143
#define IDS_COMMAND1                    301
#define IDC_STATIC_NAME                 1002
#define IDC_STATIC_PHOTO                1003
#define IDC_BUTTON_EXIT                 1003
#define IDC_COMBO_NAME                  1004
#define IDC_STATIC_ADDRESS              1005
#define IDC_EDIT_ADDRESS                1006
#define IDC_EDIT_CITY                   1007
#define IDC_EDIT_REGION                 1008
#define IDC_EDIT_POSTAL                 1009
#define IDC_EDIT_POSTAL_CODE            1009
#define IDC_EDIT_PHONE                  1010
#define IDC_EDIT_HOME_PHONE             1010
#define IDC_STATIC_HOME                 1011
#define IDC_STATIC_HOME_PHONE           1011
#define IDC_STATIC_COUNTRY              1012
#define IDC_EDIT_COUNTRY                1013
#define IDC_STATIC_HOME_PHONE2          1014
#define IDC_EDIT_EMPLOYEE_ID            1015
#define IDC_BUTTON_SAVE                 1016
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define IDM_MAIN_COMMAND_HELP           40004
#define ID_FILE                         40005
#define IDS_CAP_FILE                    40007
#define ID_FILE_EXIT                    40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
